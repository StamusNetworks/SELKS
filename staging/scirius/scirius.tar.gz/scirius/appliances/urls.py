"""
Copyright(C) 2014, Stamus Networks
Written by Eric Leblond <eleblond@stamus-networks.com>

This file is part of Scirius.

Scirius is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Scirius is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Scirius.  If not, see <http://www.gnu.org/licenses/>.
"""

from django.conf.urls import patterns, url

from appliances import views

urlpatterns = patterns('',
    url(r'^$', views.appliances, name='index'),
    url(r'^appliance/(?P<appliance_id>\d+)/$', views.appliance, name='appliance'),
    url(r'^appliance/add$', views.add_appliance, name='add_appliance'),
    url(r'^appliance/(?P<appliance_id>\d+)/edit$', views.edit_appliance, name='edit_appliance'),
    url(r'^appliance/(?P<appliance_id>\d+)/delete$', views.delete_appliance, name='delete_appliance'),
    url(r'^appliance/(?P<appliance_id>\d+)/update$', views.update_appliance, name='update_appliance'),
    )

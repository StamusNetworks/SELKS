"""
Copyright(C) 2014, Stamus Networks
Written by Eric Leblond <eleblond@stamus-networks.com>

This file is part of Scirius.
"""

from django import forms
from appliances.models import Appliance
from rules.models import Ruleset

class ApplianceForm(forms.ModelForm):
    class Meta:
        model = Appliance
        exclude = ('created_date', 'updated_date')

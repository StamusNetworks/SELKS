"""
Copyright(C) 2014, Stamus Networks
Written by Eric Leblond <eleblond@stamus-networks.com>

This file is part of Scirius.
"""


from appliances.models import Appliance
import django_tables2 as tables


class DefaultMeta:
    attrs = {"class": "paleblue"}

class ApplianceTable(tables.Table):
    name = tables.LinkColumn('appliance', args=[tables.A('pk')])
    class Meta(DefaultMeta):
        model = Appliance
        fields = ("name", "created_date", "updated_date")

"""
Copyright(C) 2014, Stamus Networks
Written by Eric Leblond <eleblond@stamus-networks.com>

This file is part of Scirius.
"""

from django.shortcuts import render, redirect, get_object_or_404
from scirius.utils import scirius_render, scirius_listing

from django.conf import settings
if settings.USE_ELASTICSEARCH:
    from rules.elasticsearch import *

from datetime import datetime
from time import time

from appliances.models import Appliance

from tables import *
from forms import *

# Create your views here.
def index(request):
    return ''

def appliances(request):
    return scirius_listing(request, Appliance, 'Appliances', table = ApplianceTable, template = "appliances/object_list.html")

def appliance(request, appliance_id):
    appliance = get_object_or_404(Appliance, pk=appliance_id)
    if request.is_ajax():
        data = { 'name': appliance.name, 'ruleset': appliance.ruleset}
        return HttpResponse(json.dumps(data),
                            content_type="application/json")
    # Get rule list
    context = {'appliance': appliance }
    if settings.USE_ELASTICSEARCH:
        from_date = int((time() - 86400) * 1000) # last 24 hours
        rules = es_get_rules_stats(request, appliance.name, from_date=from_date)
        if rules:
            context['rules'] = rules
        else:
            context['error'] = 'Unable to join Elasticsearch server or no alerts'
    return scirius_render(request, 'appliances/appliance.html', context)


def add_appliance(request):
    if request.method == 'POST':
        form = ApplianceForm(request.POST)
        if form.is_valid():
            appliance = Appliance.objects.create(name = form.cleaned_data['name'],
                    descr = form.cleaned_data['descr'],
                    created_date = datetime.now(),
                    updated_date = datetime.now(),
                    ruleset = form.cleaned_data['ruleset'],
                    )
            appliance.save()
            return redirect(appliance)
        else:
            return scirius_render(request, 'appliances/edit_appliance.html', { 'action': 'add', 'form': form, 'error': 'Invalid form' })
    else:
        form = ApplianceForm()
        return scirius_render(request, 'appliances/edit_appliance.html', { 'action': 'add', 'form': form })


def edit_appliance(request, appliance_id):
    return scirius_listing(request, Appliance, 'Appliances', table = ApplianceTable, template = "appliances/object_list.html")


def delete_appliance(request, appliance_id):
    return scirius_listing(request, Appliance, 'Appliances', table = ApplianceTable, template = "appliances/object_list.html")


def update_appliance(request, appliance_id):
    appliance = get_object_or_404(Appliance, pk=appliance_id)
    if request.method == 'POST':
        message = ""
        if request.POST['action'] == "update":
            appliance.ruleset.update()
            message += "Rule downloaded at %s. " % (appliance.ruleset.updated_date)
        appliance.generate()
        appliance.updated_date = datetime.now()
        appliance.save()
        message += "Successful ruleset build at " + str(appliance.updated_date)
        context =  { 'message': message, 'appliance': appliance }
        return scirius_render(request, 'appliances/update_appliance.html', context)
    else:
        return scirius_render(request, 'appliances/update_appliance.html', { 'appliance': appliance })

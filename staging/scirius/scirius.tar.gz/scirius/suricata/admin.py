from django.contrib import admin

# Register your models here.
from suricata.models import Suricata

admin.site.register(Suricata)
